/**
 * Controlador Principal SPA (Single Page Application) y Cliente GraphQL
 * Archivo: public/js/api.js
 *
 * Gestiona:
 * 1. Navegación reactiva por pestañas (<section>) sin recargar la página.
 * 2. Comunicación con el endpoint POST /graphql (Apollo Server 4 + SQLite).
 * 3. Sincronización automática entre las 4 vistas:
 *    - #vista-dashboard   (Req. 1: Consulta general de ventas)
 *    - #vista-nueva-venta (Req. 3: Mutación crearVenta)
 *    - #vista-factura     (Req. 2: Consulta por número de factura ventaPorFactura)
 *    - #vista-reportes    (Req. 4: Reportes PDF por HTTP y por GraphQL Base64 reportePdf)
 */

// Estado global compartido de la SPA
let allSales = [];
let currentInvoiceData = null;
let currentSelectedReportId = null; // null = reporte general, string = numeroFactura

const mutationState = {
  selectedProduct: {
    sku: 'SKU-OXF-01',
    name: 'Camisa Oxford Slim',
    unitPrice: 78900,
    size: 'M',
    quantity: 1,
  },
  cart: [
    { id: 'item-1', sku: 'SKU-OXF-01', name: 'Camisa Oxford Slim', size: 'M', qty: 1, unitPrice: 78900 },
    { id: 'item-2', sku: 'SKU-JEA-03', name: 'Jean Denim Recto', size: 'L', qty: 1, unitPrice: 92900 },
  ],
  paymentMethod: 'Tarjeta',
};

// Utilidades de formato y seguridad XSS
const money = (n) =>
  '$' + Number(n || 0).toLocaleString('es-CO', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Consultas y Mutaciones GraphQL según src/schema.js
const QUERY_VENTAS = `query ObtenerVentas {
  ventas {
    id
    numeroFactura
    fecha
    cliente
    metodoPago
    total
    items {
      id
      producto
      talla
      cantidad
      precioUnitario
      subtotal
    }
  }
}`;

const QUERY_VENTA_POR_FACTURA = `query VentaPorFactura($numeroFactura: String!) {
  ventaPorFactura(numeroFactura: $numeroFactura) {
    id
    numeroFactura
    fecha
    cliente
    metodoPago
    total
    items {
      id
      producto
      talla
      cantidad
      precioUnitario
      subtotal
    }
  }
}`;

const MUTATION_CREAR_VENTA = `mutation CrearVenta($input: VentaInput!) {
  crearVenta(input: $input) {
    id
    numeroFactura
    fecha
    cliente
    metodoPago
    total
    items {
      id
      producto
      talla
      cantidad
      precioUnitario
      subtotal
    }
  }
}`;

/**
 * Cliente HTTP para enviar operaciones al servidor Apollo GraphQL (/graphql).
 */
async function gqlRequest(query, variables = {}) {
  const t0 = performance.now();
  const res = await fetch('/graphql', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  const elapsed = Math.max(1, Math.round(performance.now() - t0));
  const raw = await res.json();
  if (raw.errors) {
    const err = new Error(raw.errors[0].message);
    err.raw = raw;
    throw err;
  }
  return { data: raw.data, elapsed, raw };
}

/* ==========================================================================
   1. NAVEGACIÓN SPA POR SECCIONES (SIN RECARGA DE PÁGINA)
   ========================================================================== */

const MAPA_VISTAS = {
  dashboard: 'vista-dashboard',
  'vista-dashboard': 'vista-dashboard',
  'ventas-registradas': 'vista-dashboard',
  'nueva-venta': 'vista-nueva-venta',
  'vista-nueva-venta': 'vista-nueva-venta',
  'nueva-venta-mutacion': 'vista-nueva-venta',
  factura: 'vista-factura',
  'vista-factura': 'vista-factura',
  'buscador-de-factura': 'vista-factura',
  reportes: 'vista-reportes',
  'vista-reportes': 'vista-reportes',
  'reportes-pdf': 'vista-reportes',
};

/**
 * Cambia la sección activa de la SPA, ocultando las demás (<section class="spa-view">)
 * y actualizando el estado visual del menú lateral y superior.
 * @param {string} nombreVista - ID o alias de la vista a mostrar.
 */
function cambiarVista(nombreVista) {
  const targetId = MAPA_VISTAS[nombreVista] || 'vista-dashboard';

  // 1. Ocultar todas las secciones y mostrar únicamente la seleccionada
  document.querySelectorAll('.spa-view').forEach((sec) => {
    if (sec.id === targetId) {
      sec.classList.remove('hidden');
    } else {
      sec.classList.add('hidden');
    }
  });

  // 2. Actualizar estado activo en todos los botones de navegación (Sidebar y Header)
  document.querySelectorAll('[data-nav-target]').forEach((btn) => {
    const esActivo = btn.getAttribute('data-nav-target') === targetId;
    const tipo = btn.getAttribute('data-nav-type');

    if (tipo === 'sidebar') {
      btn.className = esActivo
        ? 'w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-primary-container text-on-primary-container font-label-lg text-label-lg font-semibold shadow-md transition-all text-left'
        : 'w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface font-label-lg text-label-lg transition-all text-left';
    } else {
      btn.className = esActivo
        ? 'px-3 py-1.5 transition-colors bg-primary-container text-on-primary-container font-semibold rounded-lg text-label-lg'
        : 'px-3 py-1.5 rounded-lg text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface transition-colors font-label-lg text-label-lg';
    }
  });

  // 3. Actualizar hash en la URL sin provocar salto brusco
  const hashLimpio = targetId.replace(/^vista-/, '');
  if (window.location.hash !== `#${hashLimpio}`) {
    history.replaceState(null, '', `#${hashLimpio}`);
  }

  // 4. Desplazar al inicio del contenedor principal
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Navega directamente a la vista de Buscador de Factura y consulta el código indicado.
 * @param {string} numeroFactura - Código de la factura (ej. "F-0001").
 */
function irAFactura(numeroFactura) {
  const input = document.getElementById('invoiceInput');
  if (input && numeroFactura) {
    input.value = numeroFactura;
  }
  cambiarVista('vista-factura');
  handleExecuteQuery();
}

/* ==========================================================================
   2. VISTA 1: DASHBOARD DE VENTAS REGISTRADAS (#vista-dashboard)
   ========================================================================== */

function iconoMetodo(metodo) {
  const m = String(metodo || '').toUpperCase();
  if (m.includes('TARJETA')) return 'credit_card';
  if (m.includes('EFECTIVO')) return 'payments';
  if (m.includes('NEQUI')) return 'smartphone';
  return 'account_balance';
}

function actualizarMetricasDashboard(ventas, elapsed) {
  const totalFacturado = ventas.reduce((acc, v) => acc + Number(v.total || 0), 0);
  const totalPrendas = ventas.reduce(
    (acc, v) => acc + (v.items || []).reduce((s, i) => s + Number(i.cantidad || 0), 0),
    0
  );
  const ticketPromedio = ventas.length ? totalFacturado / ventas.length : 0;
  const itemsPromedio = ventas.length ? (totalPrendas / ventas.length).toFixed(1) : '0';

  document.getElementById('metricTotalVentas').textContent = money(totalFacturado);
  document.getElementById('cardTotalFacturado').textContent = `${money(totalFacturado)} facturados`;
  document.getElementById('metricTotalTx').textContent = `${ventas.length} Transacciones`;
  document.getElementById('metricPrendasCount').textContent = String(totalPrendas);
  document.getElementById('metricTicketPromedio').textContent = money(Math.round(ticketPromedio));
  document.getElementById('metricItemsPromedio').textContent = `${itemsPromedio} prendas / orden`;
  document.getElementById('metricLatency').textContent = `/graphql: ${elapsed}ms`;

  const badgeSidebar = document.getElementById('sidebarSalesCount');
  if (badgeSidebar) badgeSidebar.textContent = String(ventas.length);
}

function renderSalesTable(ventas) {
  const tbody = document.getElementById('salesTableBody');
  if (!tbody) return;

  if (!ventas.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="py-8 text-center text-on-surface-variant">No hay ventas que coincidan con el filtro seleccionado.</td></tr>`;
    document.getElementById('salesCountBadge').textContent = '0 Registros mostrados';
    return;
  }

  tbody.innerHTML = ventas
    .map((v) => {
      const itemsHtml = (v.items || [])
        .map(
          (i) => `
          <div class="flex items-center gap-2">
            <span class="truncate font-medium">${esc(i.producto)}</span>
            <span class="px-1.5 py-0.5 rounded bg-surface-container-highest text-primary font-mono font-bold text-[10px]">${esc(i.talla || 'Única')}</span>
            <span class="text-outline text-body-sm">x${Number(i.cantidad)}</span>
          </div>`
        )
        .join('');

      return `
      <tr class="sale-row hover:bg-surface-container-high/40 transition-colors">
        <td class="py-4 px-space-lg font-mono font-semibold text-primary">
          <button type="button" onclick="irAFactura('${esc(v.numeroFactura)}')" class="flex items-center gap-2 hover:underline text-primary cursor-pointer bg-transparent border-0 p-0 font-mono font-semibold">
            <span class="material-symbols-outlined text-outline text-[16px]">receipt</span>
            <span>${esc(v.numeroFactura)}</span>
          </button>
        </td>
        <td class="py-4 px-space-md">
          <div class="flex flex-col">
            <span class="font-label-lg text-label-lg font-semibold text-on-surface">${esc(v.cliente)}</span>
            <span class="font-body-sm text-body-sm text-on-surface-variant">Registro SQLite #${esc(v.id)}</span>
          </div>
        </td>
        <td class="py-4 px-space-md text-on-surface-variant whitespace-nowrap">
          <div class="flex flex-col">
            <span>${esc(v.fecha)}</span>
            <span class="font-label-sm text-label-sm text-outline">America/Bogota</span>
          </div>
        </td>
        <td class="py-4 px-space-lg">
          <div class="flex flex-col gap-1.5 max-w-sm">${itemsHtml}</div>
        </td>
        <td class="py-4 px-space-md whitespace-nowrap">
          <div class="flex items-center gap-2">
            <span class="w-6 h-6 rounded bg-surface-container-highest flex items-center justify-center text-primary text-[14px]">
              <span class="material-symbols-outlined text-[14px]">${iconoMetodo(v.metodoPago)}</span>
            </span>
            <span class="font-label-md text-label-md">${esc(v.metodoPago)}</span>
          </div>
        </td>
        <td class="py-4 px-space-lg text-right font-mono font-bold text-on-surface text-headline-sm tabular-nums">
          ${money(v.total)}
        </td>
        <td class="py-4 px-space-md text-center whitespace-nowrap">
          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-secondary-container/20 text-secondary font-label-sm text-label-sm font-semibold">
            <span class="w-1.5 h-1.5 rounded-full bg-secondary"></span>
            Completado
          </span>
        </td>
        <td class="py-4 px-space-lg text-right whitespace-nowrap">
          <div class="inline-flex items-center gap-1">
            <button class="p-1.5 rounded-lg hover:bg-surface-container-highest text-on-surface-variant hover:text-primary transition-colors"
                    onclick="inspectSale('${esc(v.numeroFactura)}')" title="Inspeccionar Payload GraphQL">
              <span class="material-symbols-outlined text-[20px]">visibility</span>
            </button>
            <button class="p-1.5 rounded-lg hover:bg-surface-container-highest text-on-surface-variant hover:text-secondary transition-colors"
                    onclick="irAFactura('${esc(v.numeroFactura)}')" title="Abrir en Buscador de Factura">
              <span class="material-symbols-outlined text-[20px]">manage_search</span>
            </button>
            <button class="p-1.5 rounded-lg hover:bg-surface-container-highest text-on-surface-variant hover:text-tertiary transition-colors"
                    onclick="downloadPdf('${esc(v.numeroFactura)}')" title="Ver / Descargar Factura PDF">
              <span class="material-symbols-outlined text-[20px]">picture_as_pdf</span>
            </button>
          </div>
        </td>
      </tr>`;
    })
    .join('');

  document.getElementById('salesCountBadge').textContent = `${ventas.length} Registros cargados`;
  document.getElementById('footerSummaryText').textContent = `Mostrando ${ventas.length} de ${allSales.length} facturas registradas en SQLite`;
}

function filterSales() {
  const searchVal = (document.getElementById('tableSearch')?.value || '').trim().toLowerCase();
  const dateVal = document.getElementById('dateFilter')?.value || 'ALL';
  const methodVal = document.getElementById('methodFilter')?.value || 'ALL';
  const hoyStr = new Date().toLocaleDateString('sv-SE');
  const mesPrefijo = hoyStr.slice(0, 7);

  const filtradas = allSales.filter((v) => {
    const textoItems = (v.items || []).map((i) => `${i.producto} ${i.talla || ''}`).join(' ');
    const textoFila = `${v.numeroFactura} ${v.cliente} ${v.fecha} ${v.metodoPago} ${textoItems}`.toLowerCase();
    const coincideTexto = !searchVal || textoFila.includes(searchVal);
    const coincideMetodo = methodVal === 'ALL' || v.metodoPago.toUpperCase().includes(methodVal);
    let coincideFecha = true;
    if (dateVal === 'today') coincideFecha = v.fecha === hoyStr;
    else if (dateVal === 'month') coincideFecha = v.fecha.startsWith(mesPrefijo);
    return coincideTexto && coincideMetodo && coincideFecha;
  });

  renderSalesTable(filtradas);
}

/**
 * Carga el listado general de ventas desde GraphQL y sincroniza todas las secciones de la SPA.
 */
async function cargarVentas(mostrarNotificacion = false) {
  const btn = document.getElementById('btnExecuteGql');
  if (btn) {
    btn.disabled = true;
    btn.classList.add('opacity-75');
  }

  try {
    const { data, elapsed, raw } = await gqlRequest(QUERY_VENTAS);
    allSales = data.ventas || [];

    // Actualizar Dashboard
    actualizarMetricasDashboard(allSales, elapsed);
    filterSales();
    document.getElementById('payloadLabel').textContent = `RESPONSE: HTTP 200 OK (${elapsed}ms)`;
    document.getElementById('codeJsonPayload').textContent = JSON.stringify(raw, null, 2);

    // Sincronizar chips del Buscador de Facturas (#vista-factura)
    renderQuickChips(allSales);

    // Sincronizar número consecutivo sugerido en Nueva Venta (#vista-nueva-venta)
    sugerirSiguienteFactura(allSales);

    // Sincronizar lista de comprobantes en Reportes PDF (#vista-reportes)
    sincronizarVistaReportes(allSales);

    if (mostrarNotificacion) {
      showToast('Query ventas Exitosa', `200 OK • ${allSales.length} ventas sincronizadas en ${elapsed}ms.`);
    }
  } catch (err) {
    showToast('Error en GraphQL', err.message);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.classList.remove('opacity-75');
    }
  }
}

function executeGraphQLQuery() {
  cargarVentas(true);
}

function refreshData() {
  cargarVentas(true);
}

async function inspectSale(facturaId) {
  try {
    const { raw, elapsed } = await gqlRequest(QUERY_VENTA_POR_FACTURA, { numeroFactura: facturaId });
    document.getElementById('payloadLabel').textContent = `RESPONSE GQL FACTURA: ${facturaId} (${elapsed}ms)`;
    document.getElementById('codeJsonPayload').textContent = JSON.stringify(raw, null, 2);
    switchDrawerTab('payload');
    toggleDrawer(true);
  } catch (err) {
    showToast('Error al inspeccionar', err.message);
  }
}

function downloadPdf(facturaId) {
  showToast('Generando Documento Fiscal', `Abriendo PDF para ${facturaId}...`);
  window.open(`/factura/${encodeURIComponent(facturaId)}/pdf`, '_blank');
}

function triggerPdfBatch() {
  showToast('Exportando Reporte General', 'Abriendo consolidado PDF de todas las ventas...');
  window.open('/reporte.pdf', '_blank');
}

function toggleDrawer(open) {
  const drawer = document.getElementById('gqlDrawer');
  const content = document.getElementById('gqlDrawerContent');
  if (!drawer || !content) return;
  if (open) {
    drawer.classList.remove('opacity-0', 'pointer-events-none');
    drawer.classList.add('opacity-100');
    content.classList.remove('translate-x-full');
  } else {
    drawer.classList.add('opacity-0', 'pointer-events-none');
    drawer.classList.remove('opacity-100');
    content.classList.add('translate-x-full');
  }
}

function switchDrawerTab(tab) {
  const pQuery = document.getElementById('panelQuery');
  const pPayload = document.getElementById('panelPayload');
  const bQuery = document.getElementById('tabQueryBtn');
  const bPayload = document.getElementById('tabPayloadBtn');

  pQuery.classList.toggle('hidden', tab !== 'query');
  pPayload.classList.toggle('hidden', tab !== 'payload');

  bQuery.className =
    tab === 'query'
      ? 'py-3 font-label-md text-label-md font-semibold text-primary border-b-2 border-primary'
      : 'py-3 font-label-md text-label-md font-semibold text-on-surface-variant hover:text-on-surface';
  bPayload.className =
    tab === 'payload'
      ? 'py-3 font-label-md text-label-md font-semibold text-primary border-b-2 border-primary'
      : 'py-3 font-label-md text-label-md font-semibold text-on-surface-variant hover:text-on-surface';
}

/* ==========================================================================
   3. VISTA 2: BUSCADOR DE FACTURA (#vista-factura)
   ========================================================================== */

function renderQuickChips(ventas) {
  const container = document.getElementById('quickChipsContainer');
  if (!container || !ventas.length) return;
  const chips = ventas
    .slice(0, 6)
    .map(
      (v) =>
        `<button type="button" class="px-2.5 py-1 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-primary font-label-sm text-label-sm transition-all hover:scale-105 cursor-pointer" onclick="setSampleInvoice('${esc(v.numeroFactura)}')">${esc(v.numeroFactura)} (${esc(v.cliente.split(' ')[0])})</button>`
    )
    .join('');
  container.innerHTML = `
    <span class="font-label-sm text-label-sm uppercase tracking-wider text-outline">Facturas en Base de Datos:</span>
    ${chips}
    <button type="button" class="px-2.5 py-1 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-error font-label-sm text-label-sm transition-all hover:scale-105 cursor-pointer" onclick="setSampleInvoice('F-9999')">F-9999 (Inexistente)</button>
  `;
}

async function handleExecuteQuery() {
  const input = document.getElementById('invoiceInput');
  const queryTerm = (input?.value || '').trim();
  const invoiceContainer = document.getElementById('invoiceContainer');
  const notFoundContainer = document.getElementById('notFoundContainer');

  try {
    const { data, raw } = await gqlRequest(QUERY_VENTA_POR_FACTURA, { numeroFactura: queryTerm });
    const venta = data?.ventaPorFactura;
    if (venta) {
      currentInvoiceData = venta;
      renderInvoiceDetail(venta, raw);
      invoiceContainer.classList.remove('hidden');
      notFoundContainer.classList.add('hidden');
    } else {
      invoiceContainer.classList.add('hidden');
      notFoundContainer.classList.remove('hidden');
      document.getElementById('notFoundMsg').innerHTML = `No se hallaron registros para la factura <strong>${esc(queryTerm)}</strong> en la base de datos SQLite.`;
      document.getElementById('notFoundJsonPre').textContent = JSON.stringify(raw, null, 2);
    }
  } catch (err) {
    invoiceContainer.classList.add('hidden');
    notFoundContainer.classList.remove('hidden');
    document.getElementById('notFoundMsg').textContent = err.message;
    if (err.raw) {
      document.getElementById('notFoundJsonPre').textContent = JSON.stringify(err.raw, null, 2);
    }
  }
}

function setSampleInvoice(invoiceCode) {
  const input = document.getElementById('invoiceInput');
  if (input) input.value = invoiceCode;
  handleExecuteQuery();
}

function renderInvoiceDetail(data, fullJson) {
  document.getElementById('invoiceDisplayNumber').innerText = data.numeroFactura;
  document.getElementById('invoiceDate').innerText = data.fecha;
  document.getElementById('invoiceTxId').innerText = `#${data.id}`;

  document.getElementById('clientName').innerText = data.cliente;
  document.getElementById('clientDetails').innerHTML = `
    Factura asociada: <strong>${esc(data.numeroFactura)}</strong><br/>
    Fecha de compra: ${esc(data.fecha)}<br/>
    Prendas adquiridas: ${(data.items || []).reduce((s, i) => s + Number(i.cantidad), 0)} unidades
  `;

  document.getElementById('paymentMethod').innerText = data.metodoPago;
  document.getElementById('paymentDetails').innerHTML = `
    Medio registrado: ${esc(data.metodoPago)}<br/>
    Estado: Cancelada en su totalidad<br/>
    Verificación: SQLite Foreign Keys ON
  `;

  const urlPdf = `/factura/${encodeURIComponent(data.numeroFactura)}/pdf`;
  document.getElementById('pdfViewLink').href = urlPdf;
  document.getElementById('pdfDownloadLink').href = `${urlPdf}?descargar=1`;

  const tbody = document.getElementById('lineItemsTableBody');
  tbody.innerHTML = (data.items || [])
    .map(
      (item) => `
      <tr class="hover:bg-surface-container-high/40 transition-colors">
        <td class="py-4 px-4 font-medium text-on-surface">
          <div class="font-label-lg text-label-lg font-semibold text-on-surface">${esc(item.producto)}</div>
          <div class="text-on-surface-variant font-body-sm text-body-sm">Prenda registrada en factura ${esc(data.numeroFactura)}</div>
        </td>
        <td class="py-4 px-3 font-mono text-[12px] text-primary">ITEM-${String(item.id).padStart(3, '0')}</td>
        <td class="py-4 px-3 text-center"><span class="px-2 py-0.5 rounded bg-surface-container-high text-on-surface font-semibold">${esc(item.talla || 'Única')}</span></td>
        <td class="py-4 px-3 text-center font-semibold text-on-surface">${Number(item.cantidad)}</td>
        <td class="py-4 px-4 text-right tabular-nums text-on-surface">${money(item.precioUnitario)}</td>
        <td class="py-4 px-4 text-right tabular-nums font-semibold text-on-surface">${money(item.subtotal)}</td>
      </tr>`
    )
    .join('');

  const total = Number(data.total || 0);
  const base = Math.round(total / 1.19);
  const iva = total - base;

  document.getElementById('txtSubtotal').innerText = money(base);
  document.getElementById('txtIva').innerText = money(iva);
  document.getElementById('txtTotal').innerText = money(total);
  document.getElementById('jsonViewer').innerText = JSON.stringify(fullJson, null, 2);
}

function toggleJsonView() {
  const wrapper = document.getElementById('jsonPayloadWrapper');
  const label = document.getElementById('jsonToggleText');
  const isHidden = wrapper.classList.contains('hidden');
  if (isHidden) {
    wrapper.classList.remove('hidden');
    label.innerText = 'Ocultar Payload';
  } else {
    wrapper.classList.add('hidden');
    label.innerText = 'Ver Payload GraphQL';
  }
}

/* ==========================================================================
   4. VISTA 3: NUEVA VENTA / MUTACIÓN (#vista-nueva-venta)
   ========================================================================== */

function sugerirSiguienteFactura(ventas) {
  const input = document.getElementById('invoice-number');
  if (!input) return;
  const mayor = Math.max(0, ...ventas.map((v) => Number(/^F-(\d+)$/i.exec(v.numeroFactura)?.[1] ?? 0)));
  input.value = 'F-' + String(mayor + 1).padStart(4, '0');
  updateGraphQLMutationPreview();
}

function updateLineCalculation() {
  const itemQtyInput = document.getElementById('item-qty');
  const itemUnitPriceInput = document.getElementById('item-unit-price');
  const itemCustomNameInput = document.getElementById('item-custom-name');
  const lineItemCalculated = document.getElementById('line-item-calculated');
  if (!itemQtyInput || !itemUnitPriceInput) return;

  const qty = parseInt(itemQtyInput.value, 10) || 1;
  const price = parseFloat(itemUnitPriceInput.value) || 0;
  mutationState.selectedProduct.quantity = qty;
  mutationState.selectedProduct.unitPrice = price;
  mutationState.selectedProduct.name = itemCustomNameInput.value;
  lineItemCalculated.textContent = money(qty * price);
  updateGraphQLMutationPreview();
}

function buildVentaInput() {
  return {
    numeroFactura: (document.getElementById('invoice-number')?.value || '').trim(),
    fecha: document.getElementById('sale-date')?.value || null,
    cliente: (document.getElementById('client-name')?.value || '').trim(),
    metodoPago: mutationState.paymentMethod,
    items: mutationState.cart.map((i) => ({
      producto: i.name.trim(),
      talla: i.size || null,
      cantidad: Number(i.qty),
      precioUnitario: Number(i.unitPrice),
    })),
  };
}

function updateGraphQLMutationPreview() {
  const gqlDisplay = document.getElementById('gql-code-display');
  if (!gqlDisplay) return;
  gqlDisplay.textContent = JSON.stringify(
    {
      query: MUTATION_CREAR_VENTA,
      variables: { input: buildVentaInput() },
    },
    null,
    2
  );
}

function updateCartTotals() {
  const total = mutationState.cart.reduce((acc, it) => acc + it.qty * it.unitPrice, 0);
  const base = Math.round(total / 1.19);
  const tax = total - base;

  document.getElementById('summary-subtotal').textContent = money(base);
  document.getElementById('summary-tax').textContent = money(tax);
  document.getElementById('summary-total').textContent = money(total);

  document.getElementById('items-badge-count').textContent = `${mutationState.cart.length} Ítem${mutationState.cart.length === 1 ? '' : 's'}`;
  document.getElementById('empty-cart-state').classList.toggle('hidden', mutationState.cart.length > 0);
  updateGraphQLMutationPreview();
}

function renderCart() {
  const cartTableBody = document.getElementById('cart-table-body');
  if (!cartTableBody) return;

  cartTableBody.innerHTML = mutationState.cart
    .map(
      (item) => `
      <tr class="hover:bg-surface-container-high/40 transition-colors">
        <td class="py-3.5 px-space-lg">
          <div class="flex flex-col">
            <span class="font-label-md text-label-md font-semibold text-on-surface">${esc(item.name)}</span>
            <span class="font-label-sm text-label-sm text-outline">${esc(item.sku)}</span>
          </div>
        </td>
        <td class="py-3.5 px-4"><span class="px-2 py-0.5 rounded bg-surface-container-lowest text-on-surface font-label-sm text-label-sm">${esc(item.size)}</span></td>
        <td class="py-3.5 px-4 text-center font-semibold text-on-surface">${Number(item.qty)}</td>
        <td class="py-3.5 px-4 text-right text-on-surface-variant font-mono">${money(item.unitPrice)}</td>
        <td class="py-3.5 px-4 text-right font-semibold text-on-surface font-mono">${money(item.qty * item.unitPrice)}</td>
        <td class="py-3.5 px-space-lg text-center">
          <button type="button" data-del-id="${esc(item.id)}" class="btn-remove-line p-1.5 rounded hover:bg-error/15 text-outline hover:text-error transition-colors" title="Eliminar ítem">
            <span class="material-symbols-outlined text-[18px]">delete</span>
          </button>
        </td>
      </tr>`
    )
    .join('');

  document.querySelectorAll('.btn-remove-line').forEach((btn) => {
    btn.onclick = function () {
      const idToRemove = this.getAttribute('data-del-id');
      mutationState.cart = mutationState.cart.filter((i) => i.id !== idToRemove);
      renderCart();
    };
  });

  updateCartTotals();
}

function showMutationBanner(type, title, msg, facturaCreada = null) {
  const toast = document.getElementById('toast-notification');
  const toastIconContainer = document.getElementById('toast-icon-container');
  const toastIcon = document.getElementById('toast-icon');
  const toastTitle = document.getElementById('toast-title');
  const toastMessage = document.getElementById('toast-message');
  const toastActions = document.getElementById('toast-actions');
  const toastBtnView = document.getElementById('toast-btn-view');
  const toastLinkPdf = document.getElementById('toast-link-pdf');

  toast.className = `transition-all duration-300 w-full rounded-xl p-space-md flex items-start justify-between gap-space-md shadow-xl ${type === 'success' ? 'bg-secondary-container/90 text-on-secondary-container' : 'bg-error-container text-on-error-container'
    }`;
  toastIconContainer.className = `w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${type === 'success' ? 'bg-secondary text-on-secondary' : 'bg-error text-on-error'
    }`;
  toastIcon.textContent = type === 'success' ? 'verified' : 'error';
  toastTitle.textContent = title;
  toastMessage.textContent = msg;

  if (facturaCreada) {
    toastActions.classList.remove('hidden');
    toastBtnView.onclick = () => irAFactura(facturaCreada);
    toastLinkPdf.href = `/factura/${encodeURIComponent(facturaCreada)}/pdf`;
  } else {
    toastActions.classList.add('hidden');
  }

  toast.classList.remove('hidden');
}

/* ==========================================================================
   5. VISTA 4: CENTRO DE REPORTES PDF (#vista-reportes)
   ========================================================================== */

function sincronizarVistaReportes(ventas) {
  const statCount = document.getElementById('statCountFacturas');
  if (statCount) statCount.textContent = `${ventas.length} registradas`;
  renderInvoiceList(ventas);
  if (ventas.length > 0 && !currentSelectedReportId) {
    loadInvoiceInPreview(ventas[0].numeroFactura);
  }
}

function renderInvoiceList(lista) {
  const container = document.getElementById('invoiceList');
  if (!container) return;

  if (!lista.length) {
    container.innerHTML = '<div class="p-4 text-center text-on-surface-variant">No se encontraron facturas.</div>';
    return;
  }

  container.innerHTML = lista
    .map((v) => {
      const resumenPrendas = (v.items || []).map((i) => i.producto).join(', ');
      return `
      <div class="invoice-item p-3 rounded-lg bg-surface-container hover:bg-surface-container-high transition-colors flex items-center justify-between gap-2 cursor-pointer group"
           onclick="loadInvoiceInPreview('${esc(v.numeroFactura)}')">
        <div class="flex items-center gap-3 min-w-0">
          <div class="w-10 h-10 rounded-lg bg-surface-container-highest flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors flex-shrink-0">
            <span class="material-symbols-outlined text-[20px]">receipt_long</span>
          </div>
          <div class="min-w-0">
            <div class="flex items-center gap-2">
              <span class="font-headline-sm text-[14px] text-on-surface font-semibold tracking-tight">${esc(v.numeroFactura)}</span>
              <span class="px-1.5 py-0.2 rounded-full bg-secondary/20 text-secondary font-label-sm text-[10px]">${esc(v.metodoPago)}</span>
            </div>
            <p class="font-body-sm text-body-sm text-on-surface-variant truncate">${esc(v.cliente)} • ${esc(resumenPrendas)}</p>
          </div>
        </div>
        <div class="flex items-center gap-2 flex-shrink-0">
          <span class="font-headline-sm text-[14px] text-on-surface font-semibold tabular-nums">${money(v.total)}</span>
          <a class="p-1.5 rounded-lg bg-surface-container-highest hover:bg-primary hover:text-on-primary text-on-surface-variant transition-colors"
             href="/factura/${encodeURIComponent(v.numeroFactura)}/pdf?descargar=1"
             onclick="event.stopPropagation()"
             title="Descargar PDF de ${esc(v.numeroFactura)}">
            <span class="material-symbols-outlined text-[18px]">download</span>
          </a>
        </div>
      </div>`;
    })
    .join('');
}

function loadInvoiceInPreview(numeroFactura) {
  const v = allSales.find((x) => x.numeroFactura === numeroFactura);
  if (!v) return;
  currentSelectedReportId = v.numeroFactura;

  document.getElementById('previewTitle').innerText = `Preview: ${v.numeroFactura}.pdf`;
  document.getElementById('docNumber').innerText = v.numeroFactura;
  document.getElementById('docClient').innerText = v.cliente;
  document.getElementById('docDate').innerText = `Fecha: ${v.fecha}`;
  document.getElementById('docPayment').innerText = v.metodoPago;

  const total = Number(v.total || 0);
  const base = Math.round(total / 1.19);
  const iva = total - base;
  document.getElementById('docSubtotal').innerText = money(base);
  document.getElementById('docTax').innerText = money(iva);
  document.getElementById('docTotal').innerText = money(total);

  const tbody = document.getElementById('docItemsBody');
  tbody.innerHTML = (v.items || [])
    .map(
      (item) => `
      <tr>
        <td class="py-2.5">
          <span class="font-medium text-slate-900 block">${esc(item.producto)}</span>
          <span class="text-[11px] text-slate-500">Ítem #${esc(item.id)}</span>
        </td>
        <td class="py-2.5 text-center font-mono">${esc(item.talla || '-')}</td>
        <td class="py-2.5 text-center">${Number(item.cantidad)}</td>
        <td class="py-2.5 text-right font-mono">${money(item.precioUnitario)}</td>
        <td class="py-2.5 text-right font-bold text-slate-900 font-mono">${money(item.subtotal)}</td>
      </tr>`
    )
    .join('');

  animarHojaPdf();
}

function previewReport(type) {
  currentSelectedReportId = null;
  const totalGeneral = allSales.reduce((acc, v) => acc + Number(v.total || 0), 0);
  const base = Math.round(totalGeneral / 1.19);
  const iva = totalGeneral - base;

  document.getElementById('docSubtotal').innerText = money(base);
  document.getElementById('docTax').innerText = money(iva);
  document.getElementById('docTotal').innerText = money(totalGeneral);
  document.getElementById('docDate').innerText = `Generado: ${new Date().toLocaleDateString('es-CO')}`;

  const tbody = document.getElementById('docItemsBody');

  if (type === 'general') {
    document.getElementById('previewTitle').innerText = 'Preview: reporte-ventas.pdf (General)';
    document.getElementById('docNumber').innerText = 'REPORTE GENERAL';
    document.getElementById('docClient').innerText = `Consolidado (${allSales.length} facturas)`;
    document.getElementById('docPayment').innerText = 'Todos los métodos';

    tbody.innerHTML = allSales
      .map(
        (v) => `
        <tr>
          <td class="py-2.5">
            <span class="font-medium text-slate-900 block">${esc(v.numeroFactura)} · ${esc(v.cliente)}</span>
            <span class="text-[11px] text-slate-500">Fecha: ${esc(v.fecha)} · Pago: ${esc(v.metodoPago)}</span>
          </td>
          <td class="py-2.5 text-center font-mono">-</td>
          <td class="py-2.5 text-center">${(v.items || []).reduce((s, i) => s + Number(i.cantidad), 0)}</td>
          <td class="py-2.5 text-right font-mono">${esc(v.metodoPago)}</td>
          <td class="py-2.5 text-right font-bold text-slate-900 font-mono">${money(v.total)}</td>
        </tr>`
      )
      .join('');
  } else if (type === 'metodos') {
    document.getElementById('previewTitle').innerText = 'Preview: Cierre-Por-Metodo-Pago.pdf';
    document.getElementById('docNumber').innerText = 'CIERRE CONTABLE';
    document.getElementById('docClient').innerText = 'Agrupación por Medio de Pago';
    document.getElementById('docPayment').innerText = 'Múltiples';

    const porMetodo = {};
    allSales.forEach((v) => {
      const m = v.metodoPago || 'Otro';
      if (!porMetodo[m]) porMetodo[m] = { count: 0, total: 0 };
      porMetodo[m].count += 1;
      porMetodo[m].total += Number(v.total || 0);
    });

    tbody.innerHTML = Object.entries(porMetodo)
      .map(
        ([metodo, info]) => `
        <tr>
          <td class="py-2.5">
            <span class="font-medium text-slate-900 block">${esc(metodo)}</span>
            <span class="text-[11px] text-slate-500">${info.count} factura(s) registrada(s)</span>
          </td>
          <td class="py-2.5 text-center font-mono">-</td>
          <td class="py-2.5 text-center">${info.count}</td>
          <td class="py-2.5 text-right font-mono">${money(Math.round(info.total / info.count))}</td>
          <td class="py-2.5 text-right font-bold text-slate-900 font-mono">${money(info.total)}</td>
        </tr>`
      )
      .join('');
  } else if (type === 'prendas') {
    document.getElementById('previewTitle').innerText = 'Preview: Prendas-Vendidas.pdf';
    document.getElementById('docNumber').innerText = 'DETALLE PRENDAS';
    document.getElementById('docClient').innerText = 'Totalidad de Ítems Vendidos';
    document.getElementById('docPayment').innerText = 'Inventario Despachado';

    const todosItems = allSales.flatMap((v) =>
      (v.items || []).map((i) => ({ ...i, factura: v.numeroFactura }))
    );
    tbody.innerHTML = todosItems
      .map(
        (item) => `
        <tr>
          <td class="py-2.5">
            <span class="font-medium text-slate-900 block">${esc(item.producto)}</span>
            <span class="text-[11px] text-slate-500">Factura ${esc(item.factura)}</span>
          </td>
          <td class="py-2.5 text-center font-mono">${esc(item.talla || '-')}</td>
          <td class="py-2.5 text-center">${Number(item.cantidad)}</td>
          <td class="py-2.5 text-right font-mono">${money(item.precioUnitario)}</td>
          <td class="py-2.5 text-right font-bold text-slate-900 font-mono">${money(item.subtotal)}</td>
        </tr>`
      )
      .join('');
  }
  animarHojaPdf();
}

function animarHojaPdf() {
  const sheet = document.getElementById('pdfSheet');
  if (!sheet) return;
  sheet.classList.add('opacity-75', 'scale-[0.99]');
  setTimeout(() => {
    sheet.classList.remove('opacity-75', 'scale-[0.99]');
  }, 150);
}

function filterInvoices(text) {
  const term = String(text || '').toLowerCase();
  document.querySelectorAll('.invoice-item').forEach((el) => {
    const str = el.innerText.toLowerCase();
    el.style.display = str.includes(term) ? 'flex' : 'none';
  });
}

function downloadActivePdf() {
  const url = currentSelectedReportId
    ? `/factura/${encodeURIComponent(currentSelectedReportId)}/pdf?descargar=1`
    : '/reporte.pdf?descargar=1';
  window.location.href = url;
}

function openInNewTab() {
  const url = currentSelectedReportId
    ? `/factura/${encodeURIComponent(currentSelectedReportId)}/pdf`
    : '/reporte.pdf';
  window.open(url, '_blank');
}

function reprintPreview() {
  window.print();
}

async function compilarPdfViaGraphQL() {
  const btn = document.getElementById('btnCompilarGql');
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span>Compilando Base64...</span>';
  try {
    const { data } = await gqlRequest(`query($n: String) { reportePdf(numeroFactura: $n) }`, {
      n: currentSelectedReportId,
    });
    const b64 = data.reportePdf;
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, '_blank');
    showToast('PDF Base64 Compilado', 'Query.reportePdf ejecutada y abierta en nueva pestaña.');
  } catch (err) {
    showToast('Error al generar PDF', err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

/* ==========================================================================
   6. TOAST GLOBAL Y PORTAPAPELES
   ========================================================================== */

let toastTimeout;
function showToast(title, desc) {
  const toast = document.getElementById('gqlToast');
  if (!toast) return;
  document.getElementById('gqlToastTitle').textContent = title;
  document.getElementById('gqlToastDesc').textContent = desc;
  toast.classList.remove('translate-y-16', 'opacity-0');
  toast.classList.add('translate-y-0', 'opacity-100');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove('translate-y-0', 'opacity-100');
    toast.classList.add('translate-y-16', 'opacity-0');
  }, 3500);
}

function copyToClipboard(elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  navigator.clipboard.writeText(el.innerText).then(() => {
    showToast('Copiado al Portapapeles', 'Fragmento GraphQL copiado correctamente.');
  });
}

function copiarInvoiceJson() {
  if (!currentInvoiceData) return;
  navigator.clipboard.writeText(JSON.stringify(currentInvoiceData, null, 2)).then(() => {
    showToast('JSON Copiado', `Payload de ${currentInvoiceData.numeroFactura} copiado al portapapeles.`);
  });
}

/* ==========================================================================
   7. INICIALIZACIÓN DE EVENTOS AL CARGAR EL DOM
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  // Inicializar fecha local en formulario de Nueva Venta
  const saleDateInput = document.getElementById('sale-date');
  if (saleDateInput) {
    saleDateInput.value = new Date().toLocaleDateString('sv-SE');
  }

  // Eventos del formulario de Nueva Venta (#vista-nueva-venta)
  ['invoice-number', 'sale-date', 'client-name', 'client-email', 'item-custom-name'].forEach((id) => {
    document.getElementById(id)?.addEventListener('input', updateGraphQLMutationPreview);
  });

  document.querySelectorAll('.product-card').forEach((card) => {
    card.addEventListener('click', function () {
      document.querySelectorAll('.product-card').forEach((c) => c.classList.remove('ring-1', 'ring-primary/40'));
      this.classList.add('ring-1', 'ring-primary/40');
      mutationState.selectedProduct.sku = this.getAttribute('data-product-id');
      mutationState.selectedProduct.name = this.getAttribute('data-name');
      document.getElementById('item-custom-name').value = mutationState.selectedProduct.name;
      document.getElementById('item-unit-price').value = parseFloat(this.getAttribute('data-price'));
      updateLineCalculation();
    });
  });

  document.querySelectorAll('.size-btn').forEach((btn) => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.size-btn').forEach((b) => {
        b.className = 'size-btn py-1.5 rounded bg-surface-container-high text-on-surface-variant font-label-sm text-label-sm hover:bg-surface-bright';
      });
      this.className = 'size-btn py-1.5 rounded bg-primary-container text-on-primary-container font-label-sm text-label-sm font-bold';
      mutationState.selectedProduct.size = this.getAttribute('data-size');
      updateGraphQLMutationPreview();
    });
  });

  document.getElementById('btn-qty-minus')?.addEventListener('click', () => {
    const inp = document.getElementById('item-qty');
    const q = parseInt(inp.value, 10) || 1;
    if (q > 1) {
      inp.value = q - 1;
      updateLineCalculation();
    }
  });

  document.getElementById('btn-qty-plus')?.addEventListener('click', () => {
    const inp = document.getElementById('item-qty');
    const q = parseInt(inp.value, 10) || 1;
    inp.value = q + 1;
    updateLineCalculation();
  });

  document.getElementById('item-qty')?.addEventListener('input', updateLineCalculation);
  document.getElementById('item-unit-price')?.addEventListener('input', updateLineCalculation);

  document.querySelectorAll('.payment-method-btn').forEach((btn) => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.payment-method-btn').forEach((b) => {
        b.className = 'payment-method-btn p-2.5 rounded-lg bg-surface-container-high text-on-surface-variant hover:text-on-surface flex flex-col items-center gap-1.5 transition-all';
      });
      this.className = 'payment-method-btn p-2.5 rounded-lg bg-primary-container text-on-primary-container flex flex-col items-center gap-1.5 transition-all';
      mutationState.paymentMethod = this.getAttribute('data-method');
      updateGraphQLMutationPreview();
    });
  });

  document.getElementById('btn-add-item')?.addEventListener('click', () => {
    const nombrePrenda = document.getElementById('item-custom-name').value.trim();
    const qty = parseInt(document.getElementById('item-qty').value, 10) || 0;
    const price = parseFloat(document.getElementById('item-unit-price').value) || 0;

    if (!nombrePrenda) {
      showMutationBanner('error', 'Prenda sin nombre', 'Por favor indique el nombre de la prenda.');
      return;
    }
    if (qty <= 0 || price <= 0) {
      showMutationBanner('error', 'Valores no válidos', 'La cantidad y el precio unitario deben ser mayores a cero.');
      return;
    }

    mutationState.cart.push({
      id: 'item-' + Date.now(),
      sku: mutationState.selectedProduct.sku || 'SKU-CUSTOM',
      name: nombrePrenda,
      size: mutationState.selectedProduct.size,
      qty,
      unitPrice: price,
    });
    renderCart();

    const btnAdd = document.getElementById('btn-add-item');
    const originalText = btnAdd.innerHTML;
    btnAdd.innerHTML = '<span class="material-symbols-outlined text-[18px]">check</span> Prenda Añadida';
    setTimeout(() => {
      btnAdd.innerHTML = originalText;
    }, 1200);
  });

  document.getElementById('btn-toggle-gql-view')?.addEventListener('click', () => {
    document.getElementById('gql-code-panel')?.classList.toggle('hidden');
  });

  document.getElementById('btn-reset-form')?.addEventListener('click', () => {
    document.getElementById('client-name').value = '';
    document.getElementById('client-email').value = '';
    mutationState.cart = [];
    renderCart();
    showMutationBanner('success', 'Formulario Reiniciado', 'Los campos y líneas de prenda han sido vaciados.');
  });

  document.getElementById('btn-execute-mutation')?.addEventListener('click', async () => {
    const btnExecute = document.getElementById('btn-execute-mutation');
    const btnSpinner = document.getElementById('mutation-btn-spinner');
    const btnIcon = document.getElementById('mutation-btn-icon');
    const btnLabel = document.getElementById('mutation-btn-label');

    if (btnExecute.disabled) return;
    const input = buildVentaInput();

    btnExecute.disabled = true;
    btnSpinner.classList.remove('hidden');
    btnIcon.classList.add('hidden');
    btnLabel.textContent = 'Ejecutando Mutación en /graphql...';

    try {
      const { data, raw } = await gqlRequest(MUTATION_CREAR_VENTA, { input });
      const creada = data.crearVenta;
      document.getElementById('gql-code-display').textContent = JSON.stringify(raw, null, 2);
      showMutationBanner(
        'success',
        `Venta Registrada: ${creada.numeroFactura}`,
        `Guardada en SQLite por un total de ${money(creada.total)} (${creada.items.length} línea(s) de prenda).`,
        creada.numeroFactura
      );
      showToast('Mutación crearVenta Exitosa', `Factura ${creada.numeroFactura} creada por ${money(creada.total)}`);
      await cargarVentas(false);
    } catch (err) {
      showMutationBanner('error', 'Mutación Rechazada (BAD_USER_INPUT)', err.message);
    } finally {
      btnExecute.disabled = false;
      btnSpinner.classList.add('hidden');
      btnIcon.classList.remove('hidden');
      btnLabel.textContent = 'Registrar Venta (Ejecutar Mutación)';
    }
  });

  // Atajo de teclado Ctrl+K / Cmd+K y Enter en Buscador de Factura
  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      cambiarVista('vista-factura');
      const input = document.getElementById('invoiceInput');
      input?.focus();
      input?.select();
    }
    if (e.key === 'Enter' && document.activeElement?.id === 'invoiceInput') {
      handleExecuteQuery();
    }
  });

  // Render inicial de Nueva Venta, Buscador de Factura y Dashboard
  renderCart();
  updateLineCalculation();
  cargarVentas(false);
  handleExecuteQuery();

  // Seleccionar vista inicial según hash de la URL (#dashboard, #nueva-venta, #factura, #reportes)
  const hashInicial = window.location.hash.replace(/^#/, '');
  if (hashInicial && MAPA_VISTAS[hashInicial]) {
    cambiarVista(hashInicial);
  } else {
    cambiarVista('vista-dashboard');
  }
});

// Exponer funciones para los atributos onclick del HTML
window.cambiarVista = cambiarVista;
window.irAFactura = irAFactura;
window.executeGraphQLQuery = executeGraphQLQuery;
window.refreshData = refreshData;
window.filterSales = filterSales;
window.inspectSale = inspectSale;
window.downloadPdf = downloadPdf;
window.triggerPdfBatch = triggerPdfBatch;
window.toggleDrawer = toggleDrawer;
window.switchDrawerTab = switchDrawerTab;
window.handleExecuteQuery = handleExecuteQuery;
window.setSampleInvoice = setSampleInvoice;
window.toggleJsonView = toggleJsonView;
window.loadInvoiceInPreview = loadInvoiceInPreview;
window.previewReport = previewReport;
window.filterInvoices = filterInvoices;
window.downloadActivePdf = downloadActivePdf;
window.openInNewTab = openInNewTab;
window.reprintPreview = reprintPreview;
window.compilarPdfViaGraphQL = compilarPdfViaGraphQL;
window.copyToClipboard = copyToClipboard;
window.copiarInvoiceJson = copiarInvoiceJson;
