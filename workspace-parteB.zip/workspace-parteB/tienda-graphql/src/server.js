/**
 * Punto de entrada del servidor HTTP estándar (Express + Apollo Server 4).
 * Expone el endpoint GraphQL (/graphql), las rutas de descarga directa de PDFs
 * y sirve la Single Page Application (SPA) ubicada en la carpeta /public.
 */
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { typeDefs } from './schema.js';
import { resolvers } from './resolvers.js';
import * as db from './db.js';
import { reporteGeneral, reporteFactura } from './pdf.js';
import { PORT } from './config.js';

const app = express();

// Inicialización de Apollo Server con el esquema y los resolvers
const server = new ApolloServer({
  typeDefs,
  resolvers,
  includeStacktraceInErrorResponses: false,
  formatError: (formateado, original) => {
    if (formateado.extensions?.code === 'INTERNAL_SERVER_ERROR') {
      console.error('Error interno en GraphQL:', original);
      return { ...formateado, message: 'Error interno del servidor' };
    }
    return formateado;
  },
});
await server.start();

// Habilitar CORS y montar el middleware de GraphQL en la ruta /graphql
app.use(cors());
app.use('/graphql', express.json({ limit: '1mb' }), expressMiddleware(server));

/**
 * Envía un PDF como respuesta HTTP.
 * Por defecto se muestra en el navegador (inline); con `?descargar=1` se fuerza la descarga.
 */
function enviarPdf(req, res, buffer, nombreBase) {
  const nombre = `${String(nombreBase).replace(/[^A-Za-z0-9_-]/g, '_')}.pdf`;
  const disposicion = req.query.descargar ? 'attachment' : 'inline';
  res
    .type('application/pdf')
    .set('Content-Disposition', `${disposicion}; filename="${nombre}"`)
    .set('Cache-Control', 'no-store')
    .send(buffer);
}

/**
 * Requerimiento 4 (Ruta directa): Descarga o visualización en navegador del reporte general en PDF.
 */
async function manejarReporteGeneral(req, res) {
  try {
    enviarPdf(req, res, await reporteGeneral(db.todasLasVentas()), 'reporte-ventas');
  } catch (err) {
    console.error('Error al generar el reporte general:', err);
    res.status(500).send('Error al generar el reporte PDF');
  }
}

app.get('/reporte.pdf', manejarReporteGeneral);
app.get('/reports/generate-pdf', manejarReporteGeneral);
app.post('/reports/generate-pdf', express.json(), manejarReporteGeneral);

/**
 * Requerimiento 4 (Ruta directa): Descarga o visualización del PDF de una factura específica.
 */
async function manejarReporteFactura(req, res) {
  try {
    const codigo = req.params.numero.replace(/\.pdf$/i, '').trim();
    const v = db.ventaPorFactura(codigo);
    if (!v) return res.status(404).send('Factura no encontrada');
    enviarPdf(req, res, await reporteFactura(v, db.itemsDe(v.id)), v.numeroFactura);
  } catch (err) {
    console.error('Error al generar el PDF de la factura:', err);
    res.status(500).send('Error al generar el PDF de la factura');
  }
}

app.get('/factura/:numero/pdf', manejarReporteFactura);
app.get('/api/pdf/:numero', manejarReporteFactura);
app.get('/pdf/:numero', manejarReporteFactura);

// Requerimiento 5: Servir la Single Page Application (SPA) unificada desde /public
const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
app.use(express.static(publicDir));

// Punto de entrada único SPA
app.get('/', (_req, res) => res.sendFile(path.join(publicDir, 'index.html')));

// Manejador final de errores de Express (p. ej. JSON mal formado en /graphql): respuesta limpia, sin stack trace
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({
    errors: [{ message: status < 500 ? 'Solicitud inválida' : 'Error interno del servidor' }],
  });
});

let httpServer;

/**
 * Inicia el servidor HTTP estándar de Express en el puerto indicado,
 * con manejo explícito de errores de red/puerto (como EADDRINUSE) y respaldo al puerto 4040.
 */
function iniciarServidor(puerto) {
  httpServer = app
    .listen(puerto, () => {
      console.log(`🚀 Servidor iniciado exitosamente en: http://localhost:${puerto}`);
      console.log(`Frontend: http://localhost:${puerto}   |   GraphQL: http://localhost:${puerto}/graphql`);
    })
    .on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.error(
          `[ERROR EADDRINUSE] Fallo al iniciar el servidor: el puerto ${puerto} ya está ocupado por otro proceso en ejecución.`
        );
        if (puerto === 4000 && !process.env.PORT) {
          console.warn('Intentando iniciar automáticamente en el puerto alternativo 4040...');
          iniciarServidor(4040);
          return;
        }
        console.error(
          `Soluciones: detenga el proceso que ocupa el puerto ${puerto} o defina otro puerto con PORT=4040 npm start`
        );
      } else {
        console.error(`[ERROR DEL SERVIDOR HTTP] Fallo crítico al escuchar en el puerto ${puerto}:`, err);
      }
      process.exit(1);
    });
}

iniciarServidor(PORT);

// Apagado ordenado (Ctrl+C o botón Stop de IntelliJ IDEA)
for (const señal of ['SIGINT', 'SIGTERM']) {
  process.on(señal, async () => {
    httpServer?.close();
    await server.stop();
    db.cerrarDb();
    process.exit(0);
  });
}


