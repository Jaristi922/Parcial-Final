/**
 * Módulo de persistencia en base de datos SQLite (better-sqlite3).
 * Gestiona la creación de tablas, consultas, inserción transaccional
 * y carga inicial de datos de prueba para la tienda de ropa.
 */
import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Ruta del archivo de base de datos: por defecto tienda.db en la raíz del proyecto.
// Se puede sobrescribir con DB_PATH (p. ej. ':memory:' para pruebas automáticas).
const dir = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(process.env.DB_PATH || path.join(dir, '..', 'tienda.db'));

// Activar integridad referencial para llaves foráneas en SQLite
db.pragma('foreign_keys = ON');

// Definición del esquema relacional: tablas "ventas" (encabezado) e "items_venta" (detalle de prendas)
db.exec(`
CREATE TABLE IF NOT EXISTS ventas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_factura TEXT NOT NULL UNIQUE,
  fecha TEXT NOT NULL,
  cliente TEXT NOT NULL,
  metodo_pago TEXT NOT NULL,
  total REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS items_venta (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  venta_id INTEGER NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
  producto TEXT NOT NULL,
  talla TEXT,
  cantidad INTEGER NOT NULL,
  precio_unitario REAL NOT NULL,
  subtotal REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_items_venta_id ON items_venta(venta_id);
`);

// Consulta base reutilizable con alias en camelCase para coincidir con el esquema GraphQL
const VENTA = `SELECT id, numero_factura AS numeroFactura, fecha, cliente, metodo_pago AS metodoPago, total FROM ventas`;

/**
 * Sentencias preparadas. Se preparan una sola vez al cargar el módulo y se reutilizan en
 * cada llamada, en lugar de recompilar el SQL en cada consulta (más rápido, sobre todo
 * cuando el resolver `Venta.items` se ejecuta una vez por cada venta listada).
 */
const sql = {
  todas: db.prepare(`${VENTA} ORDER BY fecha DESC, id DESC`),
  // COLLATE NOCASE: "f-0001" y "F-0001" se consideran la misma factura
  porFactura: db.prepare(`${VENTA} WHERE numero_factura = ? COLLATE NOCASE`),
  items: db.prepare(
    `SELECT id, producto, talla, cantidad, precio_unitario AS precioUnitario, subtotal
       FROM items_venta WHERE venta_id = ? ORDER BY id`
  ),
  insertarVenta: db.prepare(
    `INSERT INTO ventas (numero_factura, fecha, cliente, metodo_pago, total) VALUES (?,?,?,?,?)`
  ),
  insertarItem: db.prepare(
    `INSERT INTO items_venta (venta_id, producto, talla, cantidad, precio_unitario, subtotal)
     VALUES (?,?,?,?,?,?)`
  ),
  contar: db.prepare('SELECT COUNT(*) AS c FROM ventas'),
};

/**
 * Redondea valores monetarios a 2 decimales para evitar imprecisiones de punto flotante.
 * @param {number} valor - Valor numérico a redondear.
 * @returns {number} Valor con máximo 2 decimales.
 */
export const redondear = (valor) => Math.round(Number(valor) * 100) / 100;

/**
 * Requerimiento 1: Obtiene el listado general de todas las ventas ordenadas por fecha más reciente.
 * @returns {Array<Object>} Lista de ventas registradas.
 */
export const todasLasVentas = () => sql.todas.all();

/**
 * Requerimiento 2: Busca una venta específica por su número de factura único
 * (sin distinguir mayúsculas de minúsculas).
 * @param {string} numeroFactura - Código de la factura (ej. "F-0001").
 * @returns {Object|null} Datos de la venta o null si no existe.
 */
export const ventaPorFactura = (numeroFactura) => sql.porFactura.get(numeroFactura) ?? null;

/**
 * Obtiene el detalle de prendas (ítems) asociadas al identificador interno de una venta.
 * @param {number} id - ID primario de la venta.
 * @returns {Array<Object>} Lista de prendas de la venta, en el orden en que se registraron.
 */
export const itemsDe = (id) => sql.items.all(id);

/**
 * Requerimiento 3: Inserta una nueva venta junto con sus prendas dentro de una transacción atómica.
 * Si ocurre un error en cualquier ítem, se revierte toda la operación automáticamente.
 *
 * Los importes se calculan aquí a partir de precios ya redondeados, de modo que siempre se
 * cumple: subtotal = cantidad × precio y total = suma de los subtotales guardados.
 *
 * @param {Object} datos - Datos de la venta (numeroFactura, fecha, cliente, metodoPago, items).
 * @returns {Object} La venta recién creada consultada desde la base de datos.
 */
export function insertarVenta({ numeroFactura, fecha, cliente, metodoPago, items }) {
  // El número de factura se guarda siempre en mayúsculas (f-0007 -> F-0007)
  const factura = numeroFactura.trim().toUpperCase();

  const transaccion = db.transaction(() => {
    // Calcular primero cada línea con el precio redondeado, y luego el total como su suma
    const lineas = items.map((i) => {
      const precio = redondear(i.precioUnitario);
      return {
        producto: i.producto.trim(),
        talla: i.talla?.trim() || null,
        cantidad: i.cantidad,
        precio,
        subtotal: redondear(i.cantidad * precio),
      };
    });
    const total = redondear(lineas.reduce((acc, l) => acc + l.subtotal, 0));

    const { lastInsertRowid } = sql.insertarVenta.run(factura, fecha, cliente, metodoPago, total);
    for (const l of lineas) {
      sql.insertarItem.run(lastInsertRowid, l.producto, l.talla, l.cantidad, l.precio, l.subtotal);
    }
  });

  transaccion();
  return ventaPorFactura(factura);
}

/**
 * Carga de datos semilla (seed): inserta 6 ventas iniciales solo si la base de datos está vacía.
 */
function sembrarDatos() {
  if (sql.contar.get().c !== 0) return;
  const it = (producto, talla, cantidad, precioUnitario) => ({ producto, talla, cantidad, precioUnitario });
  const ventas = [
    { numeroFactura: 'F-0001', fecha: '2026-11-02', cliente: 'María Gómez', metodoPago: 'Tarjeta', items: [it('Camiseta básica', 'M', 2, 29900), it('Jean slim', '32', 1, 89900)] },
    { numeroFactura: 'F-0002', fecha: '2026-11-03', cliente: 'Carlos Ruiz', metodoPago: 'Efectivo', items: [it('Chaqueta denim', 'L', 1, 159900)] },
    { numeroFactura: 'F-0003', fecha: '2026-11-05', cliente: 'Laura Pérez', metodoPago: 'Nequi', items: [it('Vestido floral', 'S', 1, 119900), it('Sandalias', '38', 1, 69900)] },
    { numeroFactura: 'F-0004', fecha: '2026-11-08', cliente: 'Andrés Mora', metodoPago: 'Tarjeta', items: [it('Buso hoodie', 'M', 2, 99900), it('Gorra', 'Única', 1, 35900)] },
    { numeroFactura: 'F-0005', fecha: '2026-11-12', cliente: 'Sofía Herrera', metodoPago: 'Efectivo', items: [it('Falda plisada', 'M', 1, 74900), it('Camisa de lino', 'S', 2, 64900)] },
    { numeroFactura: 'F-0006', fecha: '2026-11-15', cliente: 'Juan Torres', metodoPago: 'Nequi', items: [it('Tenis urbanos', '41', 1, 189900), it('Medias (pack)', 'Única', 3, 14900)] },
  ];
  ventas.forEach((v) => insertarVenta(v));
}
sembrarDatos();

/** Cierra la conexión a la base de datos (se usa al apagar el servidor). */
export const cerrarDb = () => db.close();
