/**
 * Módulo de Resolvers de GraphQL.
 * Conecta las operaciones definidas en el esquema (Query, Mutation y campos anidados)
 * con la capa de base de datos SQLite y el generador de documentos PDF.
 */
import { GraphQLError } from 'graphql';
import * as db from './db.js';
import { reporteGeneral, reporteFactura } from './pdf.js';
import { hoy } from './config.js';

/**
 * Límites de validación. Evitan datos absurdos y protegen el diseño de los PDF
 * (textos enormes) y la precisión numérica (importes desmesurados).
 */
const LIMITES = {
  factura: 30,
  cliente: 100,
  metodoPago: 30,
  producto: 100,
  talla: 20,
  items: 200,
  cantidad: 100_000,
  precio: 1_000_000_000,
};

/**
 * Función auxiliar para emitir errores de validación estándar en GraphQL.
 * @param {string} mensaje - Descripción legible del error para el usuario/cliente.
 * @returns {GraphQLError} Instancia de error con código BAD_USER_INPUT.
 */
const errorUsuario = (mensaje) =>
  new GraphQLError(mensaje, { extensions: { code: 'BAD_USER_INPUT' } });

/**
 * Verifica que una cadena AAAA-MM-DD sea una fecha real del calendario.
 * `Date.parse` por sí solo NO sirve: acepta "2026-02-31" y la desplaza al 2 de marzo.
 * Por eso se reconstruye la fecha y se comprueba que coincida con el texto original.
 * @param {string} fecha - Fecha en formato AAAA-MM-DD.
 * @returns {boolean} true si la fecha existe.
 */
function esFechaValida(fecha) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return false;
  const d = new Date(`${fecha}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === fecha;
}

/**
 * Valida y normaliza (quita espacios) los datos de entrada de `crearVenta`.
 * @param {Object} input - Valor recibido en el argumento `input` de la mutación.
 * @returns {Object} Datos limpios listos para insertar.
 * @throws {GraphQLError} BAD_USER_INPUT si algún dato no cumple las reglas.
 */
function validarVenta(input) {
  const numeroFactura = input.numeroFactura?.trim() ?? '';
  const cliente = input.cliente?.trim() ?? '';
  const metodoPago = input.metodoPago?.trim() ?? '';
  const fecha = input.fecha?.trim() || hoy();

  // Campos obligatorios del encabezado
  if (!numeroFactura || !cliente || !metodoPago) {
    throw errorUsuario('El número de factura, el cliente y el método de pago son obligatorios');
  }
  if (numeroFactura.length > LIMITES.factura) {
    throw errorUsuario(`El número de factura no puede superar ${LIMITES.factura} caracteres`);
  }
  if (cliente.length > LIMITES.cliente) {
    throw errorUsuario(`El nombre del cliente no puede superar ${LIMITES.cliente} caracteres`);
  }
  if (metodoPago.length > LIMITES.metodoPago) {
    throw errorUsuario(`El método de pago no puede superar ${LIMITES.metodoPago} caracteres`);
  }

  // Fecha real del calendario en formato AAAA-MM-DD
  if (!esFechaValida(fecha)) {
    throw errorUsuario('La fecha debe ser válida y tener formato AAAA-MM-DD');
  }

  // Lista de prendas
  if (!Array.isArray(input.items) || input.items.length === 0) {
    throw errorUsuario('La venta debe incluir al menos una prenda');
  }
  if (input.items.length > LIMITES.items) {
    throw errorUsuario(`Una venta no puede tener más de ${LIMITES.items} prendas`);
  }

  const items = input.items.map((i, pos) => {
    const n = pos + 1; // posición legible (1, 2, 3...) para indicar cuál prenda falló
    const producto = i.producto?.trim() ?? '';
    const talla = i.talla?.trim() || null;

    if (!producto) throw errorUsuario(`Prenda #${n}: el nombre es obligatorio`);
    if (producto.length > LIMITES.producto || (talla && talla.length > LIMITES.talla)) {
      throw errorUsuario(
        `Prenda #${n}: el nombre admite hasta ${LIMITES.producto} caracteres y la talla hasta ${LIMITES.talla}`
      );
    }
    if (!Number.isInteger(i.cantidad) || i.cantidad <= 0 || i.cantidad > LIMITES.cantidad) {
      throw errorUsuario(`Prenda #${n}: la cantidad debe ser un entero entre 1 y ${LIMITES.cantidad}`);
    }
    // Se valida el precio YA redondeado: 0.001 pasaría "> 0" pero se guardaría como 0.
    if (
      !Number.isFinite(i.precioUnitario) ||
      db.redondear(i.precioUnitario) <= 0 ||
      i.precioUnitario > LIMITES.precio
    ) {
      throw errorUsuario(`Prenda #${n}: el precio unitario debe ser mayor a 0 (mínimo 0.01) y razonable`);
    }
    return { producto, talla, cantidad: i.cantidad, precioUnitario: i.precioUnitario };
  });

  return { numeroFactura, fecha, cliente, metodoPago, items };
}

export const resolvers = {
  Query: {
    /**
     * Requerimiento 1: Retorna todas las ventas registradas en la tienda.
     */
    ventas: () => db.todasLasVentas(),

    /**
     * Requerimiento 2: Consulta una venta específica por su número de factura.
     * Devuelve null (no un error) cuando la factura no existe, como es habitual en GraphQL.
     */
    ventaPorFactura: (_, { numeroFactura }) => {
      const codigo = numeroFactura?.trim();
      if (!codigo) throw errorUsuario('Debe proporcionar un número de factura para consultar');
      return db.ventaPorFactura(codigo);
    },

    /**
     * Requerimiento 4: Genera un reporte PDF en formato Base64 a través de GraphQL.
     * Si se envía "numeroFactura", genera el comprobante individual; de lo contrario, el reporte general.
     */
    reportePdf: async (_, { numeroFactura }) => {
      const codigo = numeroFactura?.trim();
      let buffer;
      if (codigo) {
        const venta = db.ventaPorFactura(codigo);
        if (!venta) throw errorUsuario(`No existe la factura ${codigo}`);
        buffer = await reporteFactura(venta, db.itemsDe(venta.id));
      } else {
        buffer = await reporteGeneral(db.todasLasVentas());
      }
      return buffer.toString('base64');
    },
  },

  Mutation: {
    /**
     * Requerimiento 3: Valida los datos de entrada y registra una nueva venta en la base de datos.
     */
    crearVenta: (_, { input }) => {
      const datos = validarVenta(input);

      // Verificar unicidad del número de factura antes de insertar (sin distinguir mayúsculas)
      if (db.ventaPorFactura(datos.numeroFactura)) {
        throw errorUsuario(`Ya existe una venta con la factura ${datos.numeroFactura}`);
      }

      try {
        return db.insertarVenta(datos);
      } catch (e) {
        // Respaldo ante condiciones de carrera: si otra petición insertó la misma factura
        // entre la verificación y el INSERT, SQLite lanza esta violación de UNIQUE.
        if (e?.code === 'SQLITE_CONSTRAINT_UNIQUE') {
          throw errorUsuario(`Ya existe una venta con la factura ${datos.numeroFactura}`);
        }
        throw e;
      }
    },
  },

  /**
   * Resolver de campo para el tipo Venta:
   * Resuelve dinámicamente la relación 1:N cargando las prendas de cada factura.
   * Con SQLite embebido (sin red) y sentencias preparadas, una consulta por venta es
   * suficientemente rápida; no se necesita DataLoader.
   */
  Venta: {
    items: (venta) => venta.items ?? db.itemsDe(venta.id),
  },
};
