/**
 * Definición del esquema GraphQL (Schema Definition Language - SDL).
 * Modela las entidades del negocio (Venta e ItemVenta), los tipos de entrada (Input)
 * para las mutaciones y las operaciones disponibles de consulta (Query) y escritura (Mutation).
 */
export const typeDefs = `#graphql
  "Representa una prenda o artículo individual dentro de una factura de venta"
  type ItemVenta {
    "Identificador único del ítem en la base de datos"
    id: ID!
    "Nombre o descripción de la prenda (ej. Camiseta básica, Jean slim)"
    producto: String!
    "Talla de la prenda (ej. S, M, L, 32, Única)"
    talla: String
    "Unidades vendidas de esta prenda"
    cantidad: Int!
    "Precio unitario de venta en pesos"
    precioUnitario: Float!
    "Subtotal calculado automáticamente (cantidad * precioUnitario)"
    subtotal: Float!
  }

  "Representa una factura de venta registrada en la tienda de ropa"
  type Venta {
    "Identificador único de la venta"
    id: ID!
    "Código único de la factura (ej. F-0001)"
    numeroFactura: String!
    "Fecha de emisión de la factura en formato AAAA-MM-DD"
    fecha: String!
    "Nombre completo del cliente"
    cliente: String!
    "Medio de pago utilizado (Efectivo, Tarjeta, Nequi, Transferencia)"
    metodoPago: String!
    "Valor total de la factura (suma de los subtotales de sus prendas)"
    total: Float!
    "Listado de prendas asociadas a esta venta"
    items: [ItemVenta!]!
  }

  "Datos de entrada requeridos por cada prenda al registrar una venta"
  input ItemVentaInput {
    producto: String!
    talla: String
    cantidad: Int!
    precioUnitario: Float!
  }

  "Datos de entrada para crear una nueva factura de venta"
  input VentaInput {
    numeroFactura: String!
    "Fecha opcional en formato AAAA-MM-DD (si se omite, se asigna la fecha actual)"
    fecha: String
    cliente: String!
    metodoPago: String!
    items: [ItemVentaInput!]!
  }

  type Query {
    "Requerimiento 1: Consulta general de todas las ventas registradas"
    ventas: [Venta!]!
    "Requerimiento 2: Consulta la información detallada de una venta por su número de factura (sin distinguir mayúsculas). Devuelve null si no existe"
    ventaPorFactura(numeroFactura: String!): Venta
    "Requerimiento 4: Genera un reporte en PDF codificado en Base64. Sin argumento: reporte general; con numeroFactura: comprobante de esa factura (error si no existe)"
    reportePdf(numeroFactura: String): String!
  }

  type Mutation {
    "Requerimiento 3: Ingresa una nueva venta con sus prendas en la base de datos"
    crearVenta(input: VentaInput!): Venta!
  }
`;

