/**
 * Configuración central de la aplicación.
 * Concentra los valores que dependen del entorno (puerto, zona horaria) para que
 * el servidor, los resolvers y el generador de PDF usen exactamente los mismos.
 */

/** Puerto HTTP del servidor (variable de entorno PORT; por defecto 4000). */
export const PORT = Number(process.env.PORT) || 4000;

/**
 * Zona horaria de la tienda. Se usa para calcular "hoy" y para la marca de tiempo de los PDF.
 * Sin esto, `new Date().toISOString()` devuelve la fecha en UTC y, en Colombia (UTC-5),
 * una venta registrada después de las 7:00 p. m. quedaría con la fecha del día siguiente.
 */
export const ZONA_HORARIA = process.env.TZ_TIENDA || 'America/Bogota';

/**
 * Fecha actual de la tienda en formato AAAA-MM-DD (el locale 'sv-SE' produce ese formato ISO).
 * @returns {string} Fecha de hoy según la zona horaria de la tienda.
 */
export const hoy = () => new Date().toLocaleDateString('sv-SE', { timeZone: ZONA_HORARIA });
