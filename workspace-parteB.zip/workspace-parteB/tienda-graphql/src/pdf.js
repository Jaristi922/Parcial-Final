/**
 * Módulo de generación de reportes en formato PDF (Requerimiento 4).
 * Utiliza PDFKit para construir documentos en memoria (Buffer) tanto para
 * el reporte general de ventas como para el comprobante individual de una factura.
 */
import PDFDocument from 'pdfkit';
import { ZONA_HORARIA } from './config.js';

/** Formateador de moneda en pesos colombianos (ej. $29.900); admite hasta 2 decimales. */
const formatoMoneda = new Intl.NumberFormat('es-CO', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
  useGrouping: 'always',
});
const money = (n) => '$' + formatoMoneda.format(Number(n));

/** Suma valores monetarios y redondea a 2 decimales (evita resultados como 2.0100000000000002). */
const sumar = (valores) => Math.round(valores.reduce((a, v) => a + Number(v), 0) * 100) / 100;

// Geometría de la página A4 (en puntos): margen, ancho útil y límites para saltar de página
const MARGEN = 40;
const DERECHA = 555; // borde derecho útil (595 - 40)
const LIMITE_FILA = 760; // si la siguiente fila empieza por debajo, se pasa a otra página
const LIMITE_TOTAL = 750; // ídem para el bloque de totales final

/**
 * Recorta el texto (añadiendo "...") hasta que quepa en el ancho indicado, medido con la
 * tipografía activa. Es más fiable que cortar por número de caracteres, porque letras
 * como "W" ocupan mucho más que "i".
 * @param {PDFDocument} doc - Documento con la fuente y el tamaño ya configurados.
 * @param {*} texto - Valor a mostrar.
 * @param {number} ancho - Ancho máximo disponible en puntos.
 * @returns {string} Texto que cabe en el ancho dado.
 */
function ajustar(doc, texto, ancho) {
  let s = String(texto ?? '');
  if (doc.widthOfString(s) <= ancho) return s;
  while (s.length > 1 && doc.widthOfString(s + '...') > ancho) s = s.slice(0, -1);
  return s + '...';
}

/**
 * Envuelve la creación del PDFDocument en una Promesa que resuelve con un Buffer completo.
 * Al terminar de dibujar, añade el pie "Página X de Y" a todas las páginas.
 * @param {string} tituloDoc - Título que se guarda en los metadatos del PDF.
 * @param {Function} draw - Función callback que dibuja el contenido sobre el documento.
 * @returns {Promise<Buffer>} Buffer binario con el archivo PDF generado.
 */
function build(tituloDoc, draw) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      margin: MARGEN,
      size: 'A4',
      bufferPages: true, // necesario para numerar las páginas al final
      info: { Title: tituloDoc, Author: 'Tienda de ropa' },
    });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    try {
      draw(doc);

      // Pie de página con numeración. Se baja temporalmente el margen inferior a 0 porque,
      // si no, PDFKit crearía una página nueva al escribir dentro de la zona del margen.
      const { start, count } = doc.bufferedPageRange();
      for (let i = 0; i < count; i++) {
        doc.switchToPage(start + i);
        const margenInferior = doc.page.margins.bottom;
        doc.page.margins.bottom = 0;
        doc
          .font('Helvetica')
          .fontSize(8)
          .fillColor('#888')
          .text(`Página ${i + 1} de ${count}`, MARGEN, doc.page.height - 30, {
            width: DERECHA - MARGEN,
            align: 'center',
            lineBreak: false,
          });
        doc.page.margins.bottom = margenInferior;
      }
      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Dibuja el encabezado corporativo estándar del reporte con fecha y hora de generación.
 */
function titulo(doc, texto) {
  doc.font('Helvetica-Bold').fontSize(18).fillColor('#111').text(texto, { align: 'center' });
  doc
    .font('Helvetica')
    .fontSize(9)
    .fillColor('#666')
    .text(
      'Tienda de ropa · generado el ' + new Date().toLocaleString('es-CO', { timeZone: ZONA_HORARIA }),
      { align: 'center' }
    );
  doc.moveDown(1.5);
}

/**
 * Dibuja una fila tabular con línea divisoria inferior y retorna la siguiente coordenada Y.
 * @param {PDFDocument} doc - Documento PDF.
 * @param {number} y - Coordenada vertical donde se dibuja la fila.
 * @param {Array} vals - Valores de cada columna.
 * @param {number[]} xs - Coordenada X de inicio de cada columna.
 * @param {boolean} negrita - true para filas de encabezado.
 * @param {number[]} [derecha=[]] - Índices de columnas alineadas a la derecha (importes).
 * @returns {number} Coordenada Y de la siguiente fila.
 */
function fila(doc, y, vals, xs, negrita, derecha = []) {
  doc.font(negrita ? 'Helvetica-Bold' : 'Helvetica').fontSize(10).fillColor('#111');
  vals.forEach((v, i) => {
    const ancho = (xs[i + 1] ?? DERECHA) - xs[i] - 6;
    // Se mide con 3 pt de holgura: si el texto queda justo al borde, PDFKit lo parte en
    // dos líneas aunque lineBreak sea false, y la segunda línea pisaría la fila siguiente.
    doc.text(ajustar(doc, v, ancho - 3), xs[i], y, {
      width: ancho,
      lineBreak: false,
      align: derecha.includes(i) ? 'right' : 'left',
    });
  });
  doc.moveTo(MARGEN, y + 15).lineTo(DERECHA, y + 15).strokeColor('#ddd').stroke();
  return y + 20;
}

/**
 * Si la siguiente fila no cabe en la página actual, crea una nueva y repite la cabecera
 * de la tabla para que cada hoja sea legible por sí sola.
 * @returns {number} Coordenada Y donde continuar dibujando.
 */
function saltoSiHaceFalta(doc, y, limite, cabecera, xs, derecha) {
  if (y <= limite) return y;
  doc.addPage();
  return cabecera ? fila(doc, MARGEN, cabecera, xs, true, derecha) : MARGEN;
}

/**
 * Genera el reporte PDF consolidado con todas las ventas registradas y el gran total acumulado.
 * @param {Array<Object>} ventas - Lista de ventas obtenidas de la base de datos.
 * @returns {Promise<Buffer>} Archivo PDF en memoria.
 */
export const reporteGeneral = (ventas) =>
  build('Reporte general de ventas', (doc) => {
    titulo(doc, 'Reporte general de ventas');
    const xs = [40, 110, 190, 340, 440];
    const cabecera = ['Factura', 'Fecha', 'Cliente', 'Pago', 'Total'];
    const derecha = [4]; // la columna Total va alineada a la derecha
    let y = fila(doc, doc.y, cabecera, xs, true, derecha);

    for (const v of ventas) {
      y = saltoSiHaceFalta(doc, y, LIMITE_FILA, cabecera, xs, derecha);
      y = fila(doc, y, [v.numeroFactura, v.fecha, v.cliente, v.metodoPago, money(v.total)], xs, false, derecha);
    }

    y = saltoSiHaceFalta(doc, y, LIMITE_TOTAL, null);
    doc
      .font('Helvetica-Bold')
      .fontSize(11)
      .fillColor('#111')
      .text(
        `Ventas: ${ventas.length}   ·   Total vendido: ${money(sumar(ventas.map((v) => v.total)))}`,
        MARGEN,
        y + 10,
        { lineBreak: false }
      );
  });

/**
 * Genera el comprobante PDF individual de una factura con el desglose de prendas compradas.
 * @param {Object} v - Datos del encabezado de la factura.
 * @param {Array<Object>} items - Lista de prendas asociadas a la factura.
 * @returns {Promise<Buffer>} Archivo PDF en memoria.
 */
export const reporteFactura = (v, items) =>
  build(`Factura ${v.numeroFactura}`, (doc) => {
    titulo(doc, 'Factura ' + v.numeroFactura);
    doc
      .font('Helvetica')
      .fontSize(11)
      .fillColor('#111')
      .text(`Fecha: ${v.fecha}`)
      .text(`Cliente: ${v.cliente}`)
      .text(`Método de pago: ${v.metodoPago}`)
      .moveDown();

    const xs = [40, 270, 330, 380, 465];
    const cabecera = ['Prenda', 'Talla', 'Cant.', 'Precio', 'Subtotal'];
    const derecha = [3, 4]; // Precio y Subtotal alineados a la derecha
    let y = fila(doc, doc.y, cabecera, xs, true, derecha);

    for (const i of items) {
      y = saltoSiHaceFalta(doc, y, LIMITE_FILA, cabecera, xs, derecha);
      y = fila(
        doc,
        y,
        [i.producto, i.talla ?? '-', i.cantidad, money(i.precioUnitario), money(i.subtotal)],
        xs,
        false,
        derecha
      );
    }

    y = saltoSiHaceFalta(doc, y, LIMITE_TOTAL, null);
    doc
      .font('Helvetica-Bold')
      .fontSize(13)
      .fillColor('#111')
      .text('TOTAL: ' + money(v.total), MARGEN, y + 12, {
        align: 'right',
        width: DERECHA - MARGEN,
        lineBreak: false,
      });
  });
