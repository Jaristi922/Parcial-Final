/**
 * Pruebas de extremo a extremo de la API (node:test, incluido en Node.js; sin dependencias extra).
 * Arranca el servidor real con una base de datos en memoria y verifica cada requerimiento:
 * consulta general, consulta por factura, registro de ventas (mutación) y reportes PDF.
 *
 * Ejecutar con:  npm test
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = 4599;
const BASE = `http://localhost:${PORT}`;
const raiz = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
let proceso;

/** Ejecuta una operación GraphQL y devuelve el JSON de respuesta. */
async function gql(query, variables) {
  const r = await fetch(`${BASE}/graphql`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  return r.json();
}

/** Mutación auxiliar para crear una venta con valores por defecto. */
const crear = (input) =>
  gql(
    `mutation($i: VentaInput!) { crearVenta(input: $i) { numeroFactura fecha total items { subtotal precioUnitario } } }`,
    { i: { cliente: 'Cliente Prueba', metodoPago: 'Efectivo', items: [{ producto: 'Camiseta', cantidad: 1, precioUnitario: 10000 }], ...input } }
  );

before(async () => {
  // Arrancar el servidor y esperar a que imprima que está listo
  proceso = spawn('node', ['src/server.js'], {
    cwd: raiz,
    env: { ...process.env, PORT: String(PORT), DB_PATH: ':memory:' },
  });
  await new Promise((resolve, reject) => {
    proceso.stdout.on('data', (d) => d.toString().includes('Frontend:') && resolve());
    proceso.stderr.on('data', (d) => reject(new Error(d.toString())));
    proceso.on('exit', (c) => reject(new Error(`El servidor terminó con código ${c}`)));
  });
});

after(() => proceso?.kill());

test('Req. 1: consulta general devuelve las 6 ventas semilla, la más reciente primero', async () => {
  const { data } = await gql('{ ventas { numeroFactura total } }');
  assert.equal(data.ventas.length, 6);
  assert.equal(data.ventas[0].numeroFactura, 'F-0006');
});

test('Req. 2: consulta por factura con detalle de prendas (y sin distinguir mayúsculas)', async () => {
  const q = `query($n: String!) { ventaPorFactura(numeroFactura: $n) { cliente total items { producto cantidad subtotal } } }`;
  const { data } = await gql(q, { n: 'F-0001' });
  assert.equal(data.ventaPorFactura.cliente, 'María Gómez');
  assert.equal(data.ventaPorFactura.items.length, 2);
  assert.equal(data.ventaPorFactura.total, 149700);
  assert.equal((await gql(q, { n: 'f-0001' })).data.ventaPorFactura.cliente, 'María Gómez');
  assert.equal((await gql(q, { n: 'NO-EXISTE' })).data.ventaPorFactura, null);
});

test('Req. 3: crearVenta registra la venta, calcula totales y asigna la fecha de hoy', async () => {
  const { data } = await crear({ numeroFactura: 'x-100', items: [
    { producto: ' Camiseta ', talla: 'M', cantidad: 2, precioUnitario: 29900 },
    { producto: 'Gorra', cantidad: 1, precioUnitario: 35900 },
  ] });
  assert.equal(data.crearVenta.numeroFactura, 'X-100'); // se normaliza a mayúsculas
  assert.equal(data.crearVenta.total, 95700);
  assert.match(data.crearVenta.fecha, /^\d{4}-\d{2}-\d{2}$/);
  const lista = await gql('{ ventas { numeroFactura } }');
  assert.equal(lista.data.ventas.length, 7);
});

test('Req. 3: el total siempre es la suma de los subtotales guardados (decimales)', async () => {
  const { data } = await crear({ numeroFactura: 'DEC-1', items: [
    { producto: 'A', cantidad: 3, precioUnitario: 0.335 },
    { producto: 'B', cantidad: 3, precioUnitario: 0.335 },
  ] });
  const suma = data.crearVenta.items.reduce((s, i) => s + i.subtotal, 0);
  assert.equal(data.crearVenta.total, Math.round(suma * 100) / 100);
});

test('Req. 3: validaciones rechazan datos inválidos con BAD_USER_INPUT', async () => {
  const casos = {
    'factura duplicada': { numeroFactura: 'F-0001' },
    'factura duplicada en minúsculas': { numeroFactura: 'f-0001' },
    'fecha inexistente (31 de febrero)': { numeroFactura: 'V-1', fecha: '2026-02-31' },
    'fecha con formato incorrecto': { numeroFactura: 'V-2', fecha: '17/11/2026' },
    'cliente vacío': { numeroFactura: 'V-3', cliente: '   ' },
    'sin prendas': { numeroFactura: 'V-4', items: [] },
    'cantidad cero': { numeroFactura: 'V-5', items: [{ producto: 'A', cantidad: 0, precioUnitario: 10 }] },
    'precio que se redondea a 0': { numeroFactura: 'V-6', items: [{ producto: 'A', cantidad: 1, precioUnitario: 0.001 }] },
    'precio negativo': { numeroFactura: 'V-7', items: [{ producto: 'A', cantidad: 1, precioUnitario: -5 }] },
    'prenda sin nombre': { numeroFactura: 'V-8', items: [{ producto: ' ', cantidad: 1, precioUnitario: 10 }] },
  };
  for (const [nombre, input] of Object.entries(casos)) {
    const r = await crear(input);
    assert.equal(r.errors?.[0]?.extensions?.code, 'BAD_USER_INPUT', `debía rechazar: ${nombre}`);
    assert.ok(!r.errors[0].extensions.stacktrace, 'no debe exponer stack trace');
  }
  // Ninguna de las ventas inválidas debe haberse guardado
  const { data } = await gql('{ ventas { numeroFactura } }');
  assert.equal(data.ventas.length, 8);
});

test('Req. 4: reportePdf (Base64) genera el reporte general y el de una factura', async () => {
  const general = await gql('{ reportePdf }');
  assert.equal(Buffer.from(general.data.reportePdf, 'base64').subarray(0, 5).toString(), '%PDF-');
  const unica = await gql('{ reportePdf(numeroFactura: "F-0001") }');
  assert.equal(Buffer.from(unica.data.reportePdf, 'base64').subarray(0, 5).toString(), '%PDF-');
  const falla = await gql('{ reportePdf(numeroFactura: "NO-EXISTE") }');
  assert.equal(falla.errors[0].extensions.code, 'BAD_USER_INPUT');
});

test('Req. 4: rutas HTTP de PDF (visualizar, descargar, 404 y nombres especiales)', async () => {
  const general = await fetch(`${BASE}/reporte.pdf`);
  assert.equal(general.status, 200);
  assert.equal(general.headers.get('content-type'), 'application/pdf');
  assert.match(general.headers.get('content-disposition'), /^inline/);

  const descarga = await fetch(`${BASE}/factura/F-0002/pdf?descargar=1`);
  assert.match(descarga.headers.get('content-disposition'), /^attachment; filename="F-0002\.pdf"/);
  assert.equal(Buffer.from(await descarga.arrayBuffer()).subarray(0, 5).toString(), '%PDF-');

  assert.equal((await fetch(`${BASE}/factura/NO-EXISTE/pdf`)).status, 404);

  // Un número de factura con un carácter fuera de Latin-1 antes provocaba HTTP 500
  await crear({ numeroFactura: '€-1' });
  assert.equal((await fetch(`${BASE}/factura/${encodeURIComponent('€-1')}/pdf`)).status, 200);
});

test('Req. 4: un reporte con muchas ventas se pagina correctamente', async () => {
  for (let n = 1; n <= 80; n++) await crear({ numeroFactura: `P-${n}`, cliente: `Cliente número ${n}` });
  const r = await fetch(`${BASE}/reporte.pdf`);
  const texto = Buffer.from(await r.arrayBuffer()).toString('latin1');
  const paginas = (texto.match(/\/Type \/Page\b/g) || []).length;
  assert.ok(paginas >= 3, `se esperaban varias páginas, hubo ${paginas}`);
});

test('Robustez: JSON mal formado devuelve 400 limpio, sin stack trace', async () => {
  const r = await fetch(`${BASE}/graphql`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{ roto',
  });
  assert.equal(r.status, 400);
  assert.ok(!(await r.text()).includes('node_modules'));
});
