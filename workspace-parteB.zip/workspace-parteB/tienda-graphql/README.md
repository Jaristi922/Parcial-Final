# API GraphQL - Ventas de una tienda de ropa

Node.js + Apollo Server + SQLite + PDFKit, con un frontend simple.

## Cómo correrlo
1. Instalar Node.js 20 o superior (nodejs.org). Verificar con `node -v`.
2. En esta carpeta: `npm install`
3. `npm start`
4. Frontend SPA Unificado (HTTP en puerto 4000):
   - **Punto de entrada único**: http://localhost:4000
   - **GraphQL (Apollo Sandbox)**: http://localhost:4000/graphql
   - **Secciones integradas en la SPA (`public/index.html` + `public/js/api.js`)**:
     - `#vista-dashboard`: Consulta general de ventas (`Query.ventas`)
     - `#vista-nueva-venta`: Registro de nuevas ventas (`Mutation.crearVenta`)
     - `#vista-factura`: Buscador de factura individual (`Query.ventaPorFactura`)
     - `#vista-reportes`: Centro de reportes PDF (`Query.reportePdf` y rutas directas)

La base de datos `tienda.db` se crea sola, con 6 ventas de ejemplo.

## Operaciones (para los pantallazos)
```graphql
# 1. Consulta general
query { ventas { numeroFactura fecha cliente metodoPago total } }

# 2. Venta por número de factura
query { ventaPorFactura(numeroFactura: "F-0002") { cliente total items { producto talla cantidad precioUnitario subtotal } } }

# 3. Nueva venta (mutación)
mutation {
  crearVenta(input: {
    numeroFactura: "F-0100", cliente: "Ana Ruiz", metodoPago: "Tarjeta",
    items: [{ producto: "Camiseta", talla: "M", cantidad: 2, precioUnitario: 29900 }]
  }) { numeroFactura total }
}

# 4. Reporte PDF (base64)
query { reportePdf }
query { reportePdf(numeroFactura: "F-0001") }
```
Reportes PDF directos (se ven en el navegador; agregue `?descargar=1` para forzar la descarga):
- http://localhost:4000/reporte.pdf
- http://localhost:4000/factura/F-0001/pdf

## Reglas de validación de `crearVenta`
- Factura, cliente y método de pago obligatorios; la factura se guarda en mayúsculas y no puede repetirse (sin distinguir mayúsculas).
- Fecha opcional AAAA-MM-DD y real del calendario (rechaza 2026-02-31). Si se omite, se usa hoy en la zona horaria de la tienda.
- Al menos una prenda; cantidad entera ≥ 1; precio ≥ 0.01. El total es siempre la suma de los subtotales guardados.

## Pruebas automáticas
`npm test` arranca el servidor con una base en memoria y verifica los 4 requerimientos funcionales, las validaciones y los PDF.

## Variables de entorno (opcionales)
`PORT` (4000), `DB_PATH` (ruta de la base; por defecto `tienda.db`), `TZ_TIENDA` (America/Bogota).

## Estructura
- `src/schema.js`: schema (tipos, queries y mutación)
- `src/resolvers.js`: lógica y validaciones
- `src/db.js`: SQLite (tablas `ventas` e `items_venta`)
- `src/config.js`: puerto, zona horaria y fecha de hoy
- `src/server.js`: Express + Apollo y rutas de PDF
- `test/api.test.js`: pruebas de extremo a extremo
- `src/pdf.js`: reportes PDF
- `public/index.html`: frontend
