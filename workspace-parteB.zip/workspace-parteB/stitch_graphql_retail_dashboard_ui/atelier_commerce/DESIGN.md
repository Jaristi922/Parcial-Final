---
name: Atelier Commerce
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#ff516a'
  on-tertiary-container: '#5b0017'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an elevated, contemporary administrative environment tailored for high-end fashion and boutique apparel retail. The interface balances high-density data requirements (inventory, line items, GraphQL-driven invoice querying) with editorial restraint, architectural clarity, and bespoke polish.

### Brand Personality & Emotional Tone
- **Curated & Authoritative:** Evoking the quiet precision of an haute couture studio rather than a generic utility dashboard.
- **Fluid & Responsive:** Fast, lightweight interactions optimized for complex multi-attribute inventory and transactional management.
- **Composed & Distraction-Free:** Interfaces prioritize garment data, invoice reconciliation, and operational metrics without visual noise.

### Design Style: Modern Structural with Muted Glassmorphism
The aesthetic fuses architectural minimalism with subtle glassmorphism and tactile micro-surfaces. Deep navy and slate backdrops establish depth, while semi-translucent container surfaces with whisper-thin borders float critical data tables, drawer panels, and summary modules above the viewport.

## Colors

The color palette utilizes a dark-first foundation designed to minimize eye strain during extended inventory curation while presenting photography and tabular data with gallery-level contrast.

### Palette Roles
- **Base Canvas (`#0B0F19`):** Deep abyssal navy serving as the foundational background layer.
- **Elevated Surfaces:** Multi-tiered slate layers (`#111827`, `#1E293B`, `#334155`) providing structured content grouping.
- **Primary Indigo (`#6366F1`):** Applied to primary actions, interactive focus rings, active navigation items, and invoice generation triggers.
- **Accent Emerald (`#10B981`):** Dedicated to revenue indicators, fulfilled orders, active stock levels, and GraphQL sync confirmations.
- **Tertiary Rose (`#F43F5E`):** Reserved for destructive operations, critical stock depletion, past-due invoices, and error states.
- **Text & Borders:** Off-white primary text (`#F8FAFC`), subdued metadata (`#94A3B8`), and hairline structural borders (`rgba(148, 163, 184, 0.08)` to `rgba(148, 163, 184, 0.16)`).

## Typography

Typography establishes strict hierarchical order between financial figures, SKU identifiers, garment naming, and dashboard controls.

### Font Pairing Strategy
- **Display & Headlines (Plus Jakarta Sans):** Modern geometric grotesk with refined proportions and warmth, bringing boutique architectural personality to section titles, key balance figures, and drawer headers.
- **Body & Numerical Labels (Inter):** Highly legible, neutral workhorse engineered for dense grids, dynamic currency values, and invoice tables.

### Numerical Standards
- Currency displays and invoice tallies must employ tabular lining numbers (`font-variant-numeric: tabular-nums`) to ensure vertical decimal alignment across line-item tables.
- SKU identifiers, GraphQL query statuses, and hash values use `label-sm` with slight positive tracking for scannability.

## Layout & Spacing

The dashboard relies on an adaptable 12-column layout designed to accommodate collapsed navigation rails, high-density data grids, and floating slide-over inspector panels.

### Breakpoints & Grid Composition
- **Desktop (≥ 1280px):** 12-column fluid grid, 24px outer margins, 24px gutters. Persistent 240px navigation rail with fluid main canvas.
- **Tablet (768px – 1279px):** 8-column layout, 24px outer margins, 20px gutters. Collapsible icon-only navigation sidebar (64px width). Tables switch to horizontal scroll wrappers with sticky ID columns.
- **Mobile (< 768px):** 4-column layout, 16px outer margins, 16px gutters. Navigation collapses into an off-canvas drawer. Multi-column invoice records stack into card clusters.

### Density & Rhythms
- Spacing follows an 8pt structural cadence with a 4pt sub-grid for input paddings and micro-badges.
- Forms and modal dialogs maintain consistent vertical stacking intervals using `space-md` for form fields and `space-xl` for distinct fieldsets.

## Elevation & Depth

Visual hierarchy uses frosted glassmorphism layered over structured tonal depths, avoiding opaque elevation drops.

### Surface Tiers
1. **Canvas Layer (`#0B0F19`):** Root background, flat and non-interactive.
2. **Surface Lower (`#111827` at 70% opacity with 12px backdrop-blur):** Applied to persistent sidebars, filter toolbars, and table headers. Finished with a 1px border (`rgba(255, 255, 255, 0.05)`).
3. **Surface Card (`#1E293B` at 65% opacity with 16px backdrop-blur):** Default for metrics cards, invoice lists, and modal bodies. Border is 1px solid `rgba(255, 255, 255, 0.08)`. Shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.35)`.
4. **Surface Floating (`#1E293B` at 90% opacity with 20px backdrop-blur):** Popovers, dropdown menus, autocomplete panels, and PDF export dialogues. Shadow: `0 16px 48px -8px rgba(0, 0, 0, 0.55)`, bordered with `rgba(99, 102, 241, 0.2)` to indicate focus.

### Hairline Borders
Outlines replace harsh drop shadows for component separation. All borders use semi-transparent white or indigo tints, ensuring elements retain structure against dark backgrounds.

## Shapes

The design system implements a controlled rounded aesthetic (`roundedness: 2`). Radii soften the administrative feel without sacrificing tabular space efficiency.

### Token Application
- **Default (0.5rem / 8px):** Input fields, select pickers, action buttons, table rows on hover, and status pills.
- **Large (`rounded-lg`, 1rem / 16px):** Metric panels, invoice data cards, slide-over modals, and image preview containers.
- **Extra Large (`rounded-xl`, 1.5rem / 24px):** Global modal containers and boutique hero metrics banners.
- **Pill (Fully rounded):** Reserved strictly for category filter tags, operational status badges (Paid, Pending, Draft), and user avatar holders.

## Components

### Buttons & Action Triggers
- **Primary ("Generate Invoice", "Add Line Item"):** Solid Indigo background (`#6366F1`), white text, subtle top inner-bevel highlight (`inset 0 1px 0 rgba(255,255,255,0.2)`). Height: 40px, padding: 0 16px.
- **Secondary / Ghost ("Export PDF", "Reset Filters"):** Translucent background (`rgba(255, 255, 255, 0.04)`), 1px border (`rgba(255, 255, 255, 0.1)`), hovering to `rgba(255, 255, 255, 0.08)`.
- **Destructive ("Remove Item"):** Muted rose ghost variant (`rgba(244, 63, 94, 0.1)`), transitioning to filled rose on confirmation.

### Data Tables (GraphQL Invoices & Inventory)
- **Header:** Sticky top position, semi-translucent backdrop (`rgba(17, 24, 39, 0.8)`), text transformed to uppercase `label-sm` tracking with muted slate color.
- **Row Architecture:** 56px row height with bottom border (`rgba(255, 255, 255, 0.04)`). Hover initiates a smooth transition to `rgba(255, 255, 255, 0.02)`.
- **Inline Numerical Cell:** Right-aligned monetary values using Inter tabular numbers for precision.

### Status Badges
- Pill-shaped with micro dot indicators (6px diameter).
- **Settled / Paid:** Emerald surface (`rgba(16, 185, 129, 0.1)`), Emerald text (`#34D399`), glowing dot (`#10B981`).
- **Pending / Processing:** Amber surface (`rgba(245, 158, 11, 0.1)`), Amber text (`#FBBF24`).
- **Overdue / Void:** Rose surface (`rgba(244, 63, 94, 0.1)`), Rose text (`#FB7185`).

### Input Fields & Search Bars
- **Invoice Search Bar:** Integrated keyboard shortcut indicator (`⌘K`), magnifying icon prefix, deep inset container background (`#0B0F19`), height 44px, placeholder text in `#64748B`.
- **Line Item Inputs:** Compact 36px inputs for inline table additions (Quantity, SKU, Price, Tax Rate). Focused inputs feature an active indigo outline (`#6366F1`) with 2px spread at 25% opacity.

### PDF & Report Action Drawer
- Dedicated sliding drawer for invoice inspection. Displays structured line-item breakdowns, subtotal, luxury tax, and discount lines, anchored with a floating action bar featuring "Download PDF" and "Direct Send".